from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Esta es la página de inicio
    path('laboratorio/', views.listar_laboratorios, name='listar_laboratorios'),
    path('laboratorio/nuevo/', views.crear_laboratorio, name='crear_laboratorio'),
    path('laboratorio/editar/<int:pk>/', views.editar_laboratorio, name='editar_laboratorio'),
    path('laboratorio/eliminar/<int:pk>/', views.eliminar_laboratorio, name='eliminar_laboratorio'),
]

from django.contrib import admin
from .models import Laboratorio, DirectorGeneral, Producto
from django import forms

class ProductoAdminForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Usar solo un campo de texto para el año
        self.fields['f_fabricacion'].widget = forms.TextInput(attrs={
            'placeholder': 'YYYY',  # Muestra solo el año
            'pattern': '[0-9]{4}',  # Valida que solo se ingresen 4 dígitos
            'title': 'Ingrese un año en formato YYYY',
        })
        # Establecer el formato para que solo se acepte el año
        self.fields['f_fabricacion'].input_formats = ['%Y']

@admin.register(Laboratorio)
class LaboratorioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'ciudad', 'pais')

@admin.register(DirectorGeneral)
class DirectorGeneralAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'laboratorio')

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    form = ProductoAdminForm
    list_display = ('nombre', 'laboratorio', 'ano_fabricacion', 'p_costo', 'p_venta')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

from django.test import TestCase
from django.urls import reverse
from .models import Laboratorio

class LaboratorioTestCase(TestCase):

    # Datos iniciales para las pruebas
    @classmethod
    def setUpTestData(cls):
        cls.laboratorio = Laboratorio.objects.create(
            nombre="Laboratorio A",
            ciudad="Ciudad X",
            pais="País Y"
        )

    # Verificar que los datos en la base de datos coinciden con lo que se creó
    def test_laboratorio_data(self):
        laboratorio = Laboratorio.objects.get(id=self.laboratorio.id)
        self.assertEqual(laboratorio.nombre, "Laboratorio A")
        self.assertEqual(laboratorio.ciudad, "Ciudad X")
        self.assertEqual(laboratorio.pais, "País Y")

    # Verificar que la URL de listar laboratorios devuelve una respuesta HTTP 200
    def test_listar_laboratorios_url(self):
        url = reverse('listar_laboratorios')  # Reemplaza con el nombre de la URL que usas para listar laboratorios
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    # Verificar que la página usa la plantilla correcta y el contenido HTML coincide con lo esperado
    def test_listar_laboratorios_template(self):
        url = reverse('listar_laboratorios')
        response = self.client.get(url)

        # Verificar que se usa la plantilla correcta
        self.assertTemplateUsed(response, 'laboratorio/listar_laboratorios.html')

        # Verificar que el contenido HTML contiene los datos correctos
        self.assertContains(response, "Laboratorio A")
        self.assertContains(response, "Ciudad X")
        self.assertContains(response, "País Y")

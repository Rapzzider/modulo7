from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .models import Laboratorio
from .forms import LaboratorioForm

# Página de inicio
def home(request):
    return render(request, 'home.html')  

# Listar laboratorios
def listar_laboratorios(request):
    # Incrementar el contador de visitas
    if 'visit_count' in request.session:
        request.session['visit_count'] += 1
    else:
        request.session['visit_count'] = 1

    # Obtener todos los laboratorios
    laboratorios = Laboratorio.objects.all()
    return render(request, 'laboratorio/listar_laboratorios.html', {'laboratorios': laboratorios})

# Crear un nuevo laboratorio
def crear_laboratorio(request):
    if request.method == 'POST':
        form = LaboratorioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_laboratorios')
    else:
        form = LaboratorioForm()
    return render(request, 'laboratorio/crear_laboratorio.html', {'form': form})

# Editar un laboratorio
def editar_laboratorio(request, pk):
    laboratorio = get_object_or_404(Laboratorio, pk=pk)
    if request.method == 'POST':
        form = LaboratorioForm(request.POST, instance=laboratorio)
        if form.is_valid():
            form.save()
            return redirect('listar_laboratorios')
    else:
        form = LaboratorioForm(instance=laboratorio)
    return render(request, 'laboratorio/editar_laboratorio.html', {'form': form})

# Eliminar un laboratorio
def eliminar_laboratorio(request, pk):
    laboratorio = get_object_or_404(Laboratorio, pk=pk)
    if request.method == 'POST':
        laboratorio.delete()
        return redirect('listar_laboratorios')
    return render(request, 'laboratorio/eliminar_laboratorio.html', {'laboratorio': laboratorio})
